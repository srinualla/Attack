var express = require("express");
var app = express();
var server = app.listen(3000);
var socket = require("socket.io");
var io = socket(server);
app.set("view engine", "ejs");
app.use("/assets", express.static("assets"));

app.get("/", function(req, res) {
    res.render("index");
});
