class Enemy {
	constructor(i, type){
		this.id = i;
		this.health = 100;
		this.from = [0, 0];
		this.to = [0, 0];
		this.position = [0, 0];
		this.departed = 0;
		this.dimensions = [0, 0];
		this.moveSpeed = 300;
		this.target = [0, 0];
		this.history = [];
		this.maxHistory = 10000;
		this.angle = 0;
		this.sideCount = 0;
		this.type = type;
		this.color = "rgb(255," + Math.floor(Math.random() * 233) + ",10)";
		this.update = function (t) {
		
			if (this.from[0] != this.to[0] || this.from[1] != this.to[1]) {
				if ((t - this.departed) >= this.moveSpeed) {
					this.setPos(this.to[0], this.to[1]);
				}
				else {
					var amt = ((tileW / this.moveSpeed) * (t - this.departed));
					var amtX = (this.from[0] == this.to[0] ? 0 : (this.to[0] < this.from[0] ? 0 - amt : amt));
					var amtY = (this.from[1] == this.to[1] ? 0 : (this.to[1] < this.from[1] ? 0 - amt : amt));
					this.position = [
						Math.floor((this.from[0] * tileW) + amtX + tileW / 3),
						Math.floor((this.from[1] * tileW) + amtY + tileH / 3)
					];
				}
			}
			else {
				if (this.from[0] != this.target[0] || this.from[1] != this.target[1]) {
					var n = new Array();
					if (this.from[0] > 0 && levels[currentLevel].map[this.from[1] * mapW + this.from[0] - 1] == 1) {
						n.push([this.from[0] - 1, this.from[1], 0]);
					}
					if (this.from[0] < mapW - 1 && levels[currentLevel].map[this.from[1] * mapW + this.from[0] + 1] == 1) {
						n.push([this.from[0] + 1, this.from[1], 0]);
					}
					if (this.from[1] > 0 && levels[currentLevel].map[(this.from[1] - 1) * mapW + this.from[0]] == 1) {
						n.push([this.from[0], this.from[1] - 1, 0]);
					}
					if (this.from[1] < mapH - 1 && levels[currentLevel].map[(this.from[1] + 1) * mapW + this.from[0]] == 1) {
						n.push([this.from[0], this.from[1] + 1, 0]);
					}
					for (i in n) {
						n[i][2] = getDistance(this.target[0], this.target[1], n[i][0], n[i][1]);
						for (var h in this.history) {
							if (n[i][0] == this.history[h][0] && n[i][1] == this.history[h][1]) {
								n[i][2] = n[i][2] + 10 + h * 10;
							}
						}
					}
					if (n.length) {
						n.sort(function (v1, v2) { return v1[2] - v2[2]; });
						this.to[0] = n[0][0];
						this.to[1] = n[0][1];
						this.departed = t;
						this.history.push([n[0][0], n[0][1]]);
						if (this.history.length > this.maxHistory) {
							this.history.shift();
						}
					}
				}
				else {
					var rand = Math.floor(Math.random()*moveableTile.length);
					var x = moveableTile[rand].x;
					var y = moveableTile[rand].y;
					this.setTarget(x, y);
				}
			}
			var petX = player.tileTo[0];
			var petY = player.tileTo[1];
			pet.setTarget(petX, petY);
			miniators.forEach(min => {
            	min.setTarget(petX, petY);
			});
		},
		this.setPos = function (px, py) {
			this.from = [px, py];
			this.to = [px, py];
			this.position = [Math.floor((px * tileW) + tileW / 3), Math.floor((py * tileW) + tileH / 3)];
			this.departed = 0;
		},
		this.setTarget = function (px, py) {
			this.history.length = 0;
			this.target = [px, py];
		};
	}

}

