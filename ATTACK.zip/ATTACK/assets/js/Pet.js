class Pet {
    constructor() {
        this.position = [0,0];
        this.dimensions = [0,0];
    }
}

