var frameCount = 0;
var shakeVel = [0,0];
var c = $("canvas")[0],
ctx = null,
// inMotion = false,
// first_move = false,
gameOver = false,
startCollision = false,
mapW = 0,
mapH = 0,
tileW = 0, tileH = 0,
moveableTile = [],
tile = {
	x:0,
	y:0
},
loadTime = 3000,
time=0,
currentSecond = 0,
gameTime		= 0,
gameSpeed		= 1,
lastFrameTime	= 0,
en_X_cordinate=0,
en_Y_cordinate=0,
eW = 0, eH = 0,
numOfEnemys = 0,
numOfCoins = 0,
numOfHealths = 0,
healthCollected = 0,
zoneRadius = 300,
drawNow = false,
// for the weapon,
totalWeapons = 13,
pick_up_gun = false,
nwid=0,
pwid=0,
gameMap,
playerSheetData = [],
playerStand=[],
spriteSpeed = 0,
enemys= [],
miniators = [],
weapons = [],
weaponData = [],
player,
zone,
maxiator = 0,
triamies = [],
playerAnimate=false,
keysDown = {
	37 : false,
	38 : false,
	39 : false,
	40 : false,
	32 : false
};

var atlas = [];
var bullets = [];
var triBullets = [];
var coins = [];
var particals = [];
var particals_2 = [];
var particals_3 = [];
var particals_4 = [];
var pw=0,ph=0;
var px=0,py=0;
var mouth = 0;
var eye = 3;
var eyeSize = 6;
var weapon={}
var playerScore = 0;
var coinObj = {
	x: 0,
	y: 0,
	r: 15
};
var bx=by=0;
var coinsCollected = 0;
var pointer = {
	x:0,
	y:0
}
var mouse = {
	x:0,
	y:0
};

var click ={
	x:0,
	y:0
}
var direction = {
	up:0,
	right:0,
	left:0,
	bottom:0,
	shoot:0
}
var rand_2 = 0;
var colors = ["rgb(50, 144, 255)","rgb(255, 144, 50)","rgb(144, 50, 255)","rgb(50, 144, 255)","rgb(255, 80, 50)"];
var rand_col = 0;
var rand_col_2 = 0;
rand_col = Math.floor(Math.random() * colors.length);
rand_col_2 = Math.floor(Math.random() * colors.length);

var healths = [];
var vx = 0,vy =0;
var sim = 0;
var al = 0;
var start = 4.72;
var diff;
var bulletCount = 0;
var img;
img = new Image();
img.src = "assets/img/atlas.png";
function drawImages(sx, sy, swidth, sheight,pos_X, pos_Y, width, height){
	ctx.drawImage(img, sx, sy, swidth, sheight,pos_X,pos_Y,width, height);
}

function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min + 1) + min);
}

var gameStatus = "Game Over";
var fire = 0;
var bulletLimit = 10;
var bulletDelay = 0;
var exit = {
	w: 0,
	h: 0,
	x: 0,
	y: 0
};
window.onload = function() {
	keysDown[32]  = false;
	pwid = 0;
	nwid = 0;
	c.width = window.innerWidth;
	c.height = window.innerHeight;
	window.addEventListener("keydown", function(e) {

		if (e.keyCode >= 37 && e.keyCode <= 40) {
			keysDown[e.keyCode] = true;
			inMotion = true;
			playerAnimate=true;
		}
		if(e.keyCode == 32){
			keysDown[32] = true;
			screenShake(true);
			// fire++;
		}
	});
	window.addEventListener("keyup", function(e) {
		pw = 0;
		ph = 0;
		px = 0;
		py = 0;
		if (e.keyCode >= 37 && e.keyCode <= 40) {
			keysDown[e.keyCode] = false;
			inMotion = false;
		}
		if (e.keyCode == 32) {
			keysDown[32] = false;
			fire = 0;
			screenShake(false);
		}
	});
	$(window).mousedown(function (e) { 
		e.preventDefault();
		// fire++;
		click.x = e.pageX;
		click.y = e.pageY;
		targetPoint = true;		
	});
	$(window).mousemove(function (e) { 
		e.preventDefault();
		mouse.x = e.pageX;
		mouse.y = e.pageY;
	});
	$(window).mouseup(function (e) { 
		e.preventDefault();
		fire = 0;
		click.x = false;
		click.y = false;
		targetPoint = false;		
	});

	window.addEventListener('touchstart', function (e) {
		e.preventDefault();
		// fire++;            
		click.x = e.touches[0].pageX;
		click.y = e.touches[0].pageY;
		targetPoint = true;
	})
	window.addEventListener('touchmove', function (e) {
		e.preventDefault();
		click.x = e.touches[0].screenX;
		click.y = e.touches[0].screenY;
		mouse.x = e.touches[0].pageX;
		mouse.y = e.touches[0].pageY;
	})
	window.addEventListener('touchend', function (e) {
		e.preventDefault();
		fire = 0;
		click.x = false;
		click.y = false;
		// mouse.x = e.touches[0].pageX;
		// mouse.y = e.touches[0].pageY;
		targetPoint = false;
	})
	$("#btn").click(function (e) { 
		e.preventDefault();
		$(".restart").css("display","none")
		reset();
		location.reload();
	});
	$("button").css("background", "rgb(255," + Math.floor(Math.random() * 200) + ",0)");
	// ctx.fillStyle = "rgb(" + Math.floor(Math.random() * 255) + "," + Math.floor(Math.random() * 255) +"," + Math.floor(Math.random() * 255) +")";
};

function reset(){
	frameCount = 0;
	shakeVel = [0,0];
	c = $("canvas")[0],
	ctx = null,
	// inMotion = false,
	// first_move = false,
	gameOver = false,
	startCollision = false,
	mapW = 0,
	mapH = 0,
	tileW = 0, tileH = 0,
	moveableTile = [],
	tile = {
		x:0,
		y:0
	},
	loadTime = 3000,
	time=0,
	currentSecond = 0,
	gameTime		= 0,
	gameSpeed		= 1,
	lastFrameTime	= 0,
	en_X_cordinate=0,
	en_Y_cordinate=0,
	eW = 0, eH = 0,
	numOfEnemys = 0,
	numOfCoins = 0,
	numOfHealths = 0,
	healthCollected = 0,
	zoneRadius = 300,
	drawNow = false,
	// for the weapon,
	totalWeapons = 13,
	pick_up_gun = false,
	nwid=0,
	pwid=0,
	gameMap,
	playerSheetData = [],
	playerStand=[],
	spriteSpeed = 0,
	enemys= [],
	miniators = [],
	weapons = [],
	weaponData = [],
	player,
	zone,
	maxiator = 0,
	triamies = [],
	playerAnimate=false,
	keysDown = {
		37 : false,
		38 : false,
		39 : false,
		40 : false,
		32 : false
	};

	atlas = [];
	bullets = [];
	triBullets = [];
	coins = [];
	particals = [];
	particals_2 = [];
	particals_3 = [];
	particals_4 = [];
	pw=0,ph=0;
	px=0,py=0;
	mouth = 0;
	eye = 3;
	eyeSize = 6;
	weapon={}
	playerScore = 0;
	coinObj = {
		x: 0,
		y: 0,
		r: 15
	};
	bx=by=0;
	coinsCollected = 0;
	pointer = {
		x:0,
		y:0
	}
	mouse = {
		x:0,
		y:0
	};

	click ={
		x:0,
		y:0
	}
	direction = {
		up:0,
		right:0,
		left:0,
		bottom:0,
		shoot:0
	}
	rand_2 = 0;
	colors = ["rgb(50, 144, 255)","rgb(255, 144, 50)","rgb(144, 50, 255)","rgb(50, 144, 255)","rgb(255, 80, 50)"];
	rand_col = 0;
	rand_col_2 = 0;
	rand_col = Math.floor(Math.random() * colors.length);
	rand_col_2 = Math.floor(Math.random() * colors.length);

	healths = [];
	vx = 0,vy =0;
	sim = 0;
	al = 0;
	start = 4.72;
	diff;
	img;
	bulletCount = 0;
	gameStatus = "Game Over";
	fire = 0;
	bulletLimit = 10;
	bulletDelay = 0;
	exit = {
		w: 0,
		h: 0,
		x: 0,
		y: 0
	};

}
var camera = {
	screen		: [0,0],
	startTile	: [0,0],
	endTile		: [0,0],
	offset		: [0,0],
	update		: function(px, py) {

		this.offset[0] = Math.floor((this.screen[0]/1.5) - px);
		this.offset[1] = Math.floor((this.screen[1]/1.5) - py);
		var tile = [ Math.floor(px/tileW), Math.floor(py/tileH) ];

		this.startTile[0] = tile[0] - 1 - Math.ceil((this.screen[0]/1.5) / tileW);
		this.startTile[1] = tile[1] - 1 - Math.ceil((this.screen[1]/1.5) / tileH);

		if(this.startTile[0] < 0) { this.startTile[0] = 0; }
		if(this.startTile[1] < 0) { this.startTile[1] = 0; }

		this.endTile[0] = tile[0] + 1 + Math.ceil((this.screen[0]/1.5) / tileW);
		this.endTile[1] = tile[1] + 1 + Math.ceil((this.screen[1]/1.5) / tileH);

		if(this.endTile[0] >= mapW) { this.endTile[0] = mapW-1; }
		if(this.endTile[1] >= mapH) { this.endTile[1] = mapH-1; }
	}
};
