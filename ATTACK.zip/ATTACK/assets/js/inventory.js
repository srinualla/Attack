function Inventory(){
    this.x = 0;
    
}