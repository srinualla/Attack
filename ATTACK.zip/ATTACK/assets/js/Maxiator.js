function Maxiator(px, py) {
    this.dimensions = [tileW, tileH];
    this.fromTile = [px, py];
    this.position = [px*tileW, py*tileH];
    this.generator = function() {
        var i = 0;
        miniator = new Enemy(i);
        miniator.dimensions = [this.dimensions[0]/4, this.dimensions[1]/4];
        miniator.moveSpeed = 1200;
        miniator.setPos(this.fromTile[0],this.fromTile[1]);
        miniator.setTarget(this.fromTile[0],this.fromTile[1]);
        miniator.sideCount = getRandomInt(3,10);
        miniators.push(miniator);
        i++;

        setInterval(() => {
            miniator = new Enemy(i);
            miniator.dimensions = [this.dimensions[0]/4, this.dimensions[1]/4];
            miniator.moveSpeed = 1200;
            miniator.sideCount = getRandomInt(1,5);
            miniator.setPos(this.fromTile[0],this.fromTile[1]);
            miniator.setTarget(this.fromTile[0],this.fromTile[1]);
            miniators.push(miniator);
            i++;
        }, 4000);
    }
}