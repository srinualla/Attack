class Coins {
    constructor(x, y, tileW, tileH) {
        this.r = tileW/6;
        this.x = x * tileW + tileW / 3;
        this.y = y * tileH + tileH / 3;
        this.draw = function () {
            ctx.shadowBlur = 5;
            ctx.shadowColor = "rgb(255, 208, 0)";
            drawImages(400,0,50,50, camera.offset[0] + this.x, camera.offset[1] + this.y, this.r * 2, this.r * 2);
            ctx.shadowColor = "transparent";
        };
        this.checkCollision = function () {
            for (let i = coins.length - 1; i > -1; i--) {
                if (circlerect(coins[i], player.position[0], player.position[1], player.dimensions[0], player.dimensions[1])) {
                    coins.splice(i, 1);
                    coinsCollected += 1;
                }
            }
        };
    }
}
