class Bullet {
    constructor(x, y, r, color,angle, range, damgeRate, type, speed){
        this.position = [x, y];
        this.x = x;
        this.y = y;
        this.r = r;
        this.color = color;
        this.angle = angle;
        this.range = range;
        this.damgeRate = damgeRate;
        this.type = type;
        this.speed = speed;
    }
    draw = function () {
        ctx.shadowBlur = 20;
        ctx.shadowColor = this.color;
        ctx.fillStyle = this.color;

        ctx.beginPath();
        ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2, false);
        ctx.fill();
        ctx.shadowColor = "transparent";
    };
    
    update = function () {
        this.x -= this.speed * Math.cos(this.angle);
        this.y -= this.speed * Math.sin(this.angle);
    };

    checkEnemyCollision = function (ind) {
        var triamiyTested = false;
        if(enemys.length > 0){
            for (let j = enemys.length - 1; j > -1; j--) {
                if (circlerect(bullets[ind], camera.offset[0] + enemys[j].position[0], camera.offset[1] + enemys[j].position[1], eW, eH) && this.type == "enemy") {
                    screenShake(true);
                    triamiyTested = true;
                    for (let i = 0; i < 10; i++) {
                        var part = new Particals(this.x, this.y, "rgb(255,"+ Math.floor(Math.random()*233)+ ",10)", true);
                        particals.push(part);
                        particals[i].update();
                    }
    
                    bullets.splice(ind, 1);
                    enemys[j].health -= this.damgeRate;
    
                    if (enemys[j].health <= 0) {
                        playerScore += this.damgeRate;
                        if (player.health < 25) {
                            player.health += 5;
                        }
                        enemys.splice(j, 1);
                    }            
                    break;
                }
            }
        }

        if(triamiyTested == false && triamies.length > 0){
            for (let j = triamies.length - 1; j > -1; j--) {
                if (circlerect(bullets[ind], camera.offset[0] + triamies[j].position[0], camera.offset[1] + triamies[j].position[1], eW, eH) && this.type == "enemy") {    
                    screenShake(true);
                    for (let i = 0; i < 10; i++) {
                        var part = new Particals(this.x, this.y, "rgb(255,"+ Math.floor(Math.random()*233)+ ",10)", true);
                        particals.push(part);
                        particals[i].update();
                    }
    
                    bullets.splice(ind, 1);
                    triamies[j].health -= this.damgeRate;
                    
                    if (triamies[j].health <= 0) {
                        triamies.splice(j, 1);
                    }
    
                    break;
                }
            }
        }    
        
        if(this.position[0] + this.range <= this.x || this.position[1] + this.range <= this.y){
            bx = this.x;
            by = this.y;
            for (let i = 0; i < 3; i++) {
                var part = new Particals(bx,by,"#aaa", true, "rect");
                particals.push(part);
                particals[i].update();
            }
            bullets.splice(ind,1);
        }
    };

    checkTriamyBulletCollision = function(i) {        
        var tested = false;
        if(circlerect(triBullets[i], camera.offset[0] + player.position[0], camera.offset[1] + player.position[1], player.dimensions[0], player.dimensions[1])){
            tested = true;
            player.health -= this.damgeRate;
            bx = this.x;
            by = this.y;
            for (let i = 0; i < 3; i++) {
                var part = new Particals(bx,by,"#aaa", true, "arc");
                particals.push(part);
                particals[i].update();
            }
            triBullets.splice(i,1)
        }
        // if(tested == false){
        //     if(circlerect(triBullets[i], camera.offset[0] + pet.position[0], camera.offset[1] +pet.position[1], pet.dimensions[0], pet.dimensions[1])){
        //         pet.health -= this.damgeRate;
        //         triBullets.splice(i,1)
        //     }
        // }

        // if(this.position[0] + this.range <= this.x || this.position[1] + this.range <= this.y){
        //     for (let i = 0; i < 3; i++) {
        //         var part = new Particals(bx,by,"#aaa", true, "arc");
        //         particals.push(part);
        //         particals[i].update();
        //     }
        //     triBullets.splice(i,1);
        // }
    }
}