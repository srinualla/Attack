class Health{
    constructor(x, y, tileW, tileH){
        this.r = tileW;
        this.x = x * tileW + tileW / 4;
        this.y = y * tileH + tileH / 3;
    }
    draw = function () {
        drawImages(350,0,50,50, camera.offset[0] + this.x, camera.offset[1] + this.y, this.r / 2, this.r / 2);
    };
    checkCollision = function () {
        for (let i = healths.length - 1; i > -1; i--) {
            if (circlerect(healths[i], player.position[0], player.position[1], player.dimensions[0], player.dimensions[1]) && player.health < 75) {
                healths.splice(i, 1);
                healthCollected += 1;
            }
        }
    };
}
$(".health").click(function (e) { 
    e.preventDefault();
    if(healthCollected > 0){
        healthCollected -= 1;
        player.health += 10;
        pet.health += 10;
    }
});
