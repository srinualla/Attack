class Character {
	constructor() {
		this.tileFrom = [2, 1];
		this.tileTo = [2, 1];
		this.timeMoved = 0;
		this.dimensions = [80, 100];
		this.position = [0, 0];
		this.delayMove = 300;
		this.health = 100;
		this.color = "rgb(100, 255, 144)";
	}
	placeAt(x, y) {
		this.tileFrom = [x, y];
		this.tileTo = [x, y];
		this.position = [((tileW * x) + ((tileW - this.dimensions[0]) / 2)),
		((tileH * y) + ((tileH - this.dimensions[1])))];
	}
	processMovement(t) {
		var distX = (tileW / this.delayMove) * (t - this.timeMoved);
		var distY = (tileH / this.delayMove) * (t - this.timeMoved);
		if (!gameOver) {

			if (player.health <= 0) {
				gameStatus = "Game Over";
				gameOver = true;
				
			}

			enemys.forEach(enemy => {
				if (getDistance(player.position[0], player.position[1], enemy.position[0], enemy.position[1]) < (eW + (eW / 5)) && startCollision) {
					player.health -= 0.5;
				}
			});

			if ((t - this.timeMoved) >= this.delayMove) {
				this.placeAt(this.tileTo[0], this.tileTo[1]);
			}
			else {
				this.position[0] = (this.tileFrom[0] * tileW) + ((tileW - this.dimensions[0]) / 2);
				this.position[1] = (this.tileFrom[1] * tileH) + ((tileH - this.dimensions[1]));
				if (this.tileTo[0] != this.tileFrom[0]) {
					this.position[0] += (this.tileTo[0] < this.tileFrom[0] ? 0 - distX : distX);
				}
				if (this.tileTo[1] != this.tileFrom[1]) {
					this.position[1] += (this.tileTo[1] < this.tileFrom[1] ? 0 - distY : distY);
				}
			}
			if (this.tileFrom[0] == this.tileTo[0] && this.tileFrom[1] == this.tileTo[1]) {
				return false;
			}
			return true;
		}
	}
}


