var x = 30;
var y = 30;
var lx = 10;
var ly = 10;
var w = x - 10;
var h = y - 10;
function Controls(x,y,sx,sy,title){

    this.title = title;
    this.w = w;
    this.h = h;
    this.x = x;
    this.y = y;
    this.sx = sx;
    this.sy = sy;
    this.draw = function(){
        if(this.title === "shoot"){
            this.w += 10;
            this.h += 10;
            this.x -= 2;
            this.y -= 2;
        }
        drawImages(this.sx,this.sy,50,50,this.x,this.y,this.w,this.h);
    }

    this.draw();

    this.clicked = function() {
        var left = this.x;
        var right = this.x + (this.w);
        var top = this.y;
        var bottom = this.y + (this.h);
        var check = true;
        if ((bottom < click.y) || (top > click.y) || (right < click.x) || (left > click.x)) {
            check = false;
        }
        return check;
    }
}

function controllers() {
    ctx.fillStyle = "#f5f5f520";
    ctx.strokeStyle = "#555";
    ctx.beginPath();
    ctx.arc(80, c.height - 60,48, 0, 2 * Math.PI);
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fill();

    var r = 11;
    ctx.beginPath();
    ctx.arc(lx + x*5 + r - 1, c.height - ly - y*3 + r - 1, r*2, 0, 2 * Math.PI);
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fill();

    direction.up = new Controls(lx + x*2, c.height - ly  - y*3,0,0,"up");
    direction.left = new Controls(lx + x, c.height - ly - y*2,100,0,"left");
    direction.down = new Controls(lx + x*2, c.height - ly  - y,50,0,"down");
    direction.right = new Controls(lx + x*3, c.height - ly - y*2,150,0,"right");	
    direction.shoot = new Controls(lx + x*5 - x/10, c.height - ly - y*3 - y/10,200,0,"shoot");

    function keys(key){
        pw = 0;
        ph = 0;
        px = 0;
        py = 0;
        keysDown[37] = false;
        keysDown[38] = false;
        keysDown[39] = false;
        keysDown[40] = false;
        keysDown[32] = false;
        keysDown[key] = true;
    }

    if (click.x && click.y) {
        if (direction.shoot.clicked() && fire <= bulletLimit) {
            keys(32);
        }else{
            keysDown[32] = false;
        }
        if (direction.up.clicked()) {
            keys(38);
        }else{
            keysDown[38] = false;
        }
        if (direction.down.clicked()) {
            keys(40);    
        }else{
            keysDown[40] = false;
        }
        if (direction.left.clicked()) {
            keys(37);    
        }else{
            keysDown[37] = false;
        }
        if (direction.right.clicked()) {
            keys(39);
        }else{
            keysDown[39] = false;
        }
    }
    else{
        keysDown[37] = false;
        keysDown[38] = false;
        keysDown[39] = false;
        keysDown[32] = false;
        keysDown[40] = false;
    }
}



