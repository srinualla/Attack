var rotationDegrees=0;
var rotationIncrement=1;
var nextTime=0;
var delay=1000/60*1;
$("#next").click(function (e) { 
	e.preventDefault();
	time = 0;
	currentLevel++;
	$(".nxt").css("display", "none");
	$(".restart").css("display", "none");
	healthCollected = 0;
	console.log(healthCollected);
	reset();
	setup();
});

function Resized() {
	reset();
	c.width = $(window).innerWidth();
	c.height = $(window).innerHeight();

	tileW = Math.floor(c.width/10);
	tileH = Math.floor(c.width/10);

	if(tileW >= 100 || tileH >= 100){
		tileW = 100;
		tileH = 100;
	}
	ctx = c.getContext("2d");
	camera.screen = [c.width, c.height];
	$(".nxt").css("display", "none");
	$(".restart").css("display", "none");
	time = 0;
	setup();
}

$(window).resize(function() {
	Resized();
});
Resized();

function movebleTiles() {
    for (let j = 0; j < mapH; j++) {
        for (let i = 0; i < mapW; i++) {
            const element = levels[currentLevel].map[((j*mapW)+i)];
            if(element === 1){
                tile = {
                    x: i,
                    y: j
                }
                moveableTile.push(tile);
            }
        }
    }
}

function setup() {
	// enemys = [];
	// triamies = [];
	// triBullets = [];
	// miniators = [];
	// coins = [];
	// bullets = [];
	// healths = [];
    // gameOver = false;
	// drawNow = false;
	// startCollision = false;
    // moveableTile = [];
	// healthCollected = 0;
	if(currentLevel == levels.length){
		gameStatus = "Levels completed";
		gameOver = true;
		$(".nxt").css("display", "none");
	}else{

		mapW = levels[currentLevel].width;
        mapH = levels[currentLevel].height;
        
        movebleTiles();

		numOfEnemys = Math.floor((mapW+mapH)/2);
		numOfCoins = Math.floor((mapW+mapH)/2);
		numOfHealths = Math.floor((mapW+mapH)/10);
			
		for (let i = 0; i < numOfCoins; i++) {
            var rand = Math.floor(Math.random()*moveableTile.length);
            var x = moveableTile[rand].x;
            var y = moveableTile[rand].y;
            console.log();
            
			coins.push(new Coins( x, y, tileW,tileH));
        }

		for (let i = 0; i < 3; i++) {
            var rand = Math.floor(Math.random()*moveableTile.length);
            var x = moveableTile[rand].x;
            var y = moveableTile[rand].y;
			healths.push(new Health( x, y, tileW,tileH));
        }
        
		player = new Character();
		pet = new Enemy();
		zone = new Character();
		pet.setPos(player.tileFrom[0], player.tileFrom[1]);
	
		// if(currentLevel == 3){
			for(var i=0;i<Math.floor(numOfEnemys/2);i++){
				var enemy = new Enemy(i);
				enemy.dimensions = [eW, eH];
				enemys.push(enemy);
			}
			
			enemys.forEach(enemy => {
				var rand = Math.floor(Math.random()*moveableTile.length);
				var x = moveableTile[rand].x;
				var y = moveableTile[rand].y;
				enemy.setPos(x, y);
				enemy.setTarget(x, y);
			});
	
			for (let i = 0; i < Math.floor(numOfEnemys/2); i++) {
				var rand = Math.floor(Math.random()*moveableTile.length);
				var x = moveableTile[rand].x;
				var y = moveableTile[rand].y;
				triamies.push(new Enemy());
			}
	
			triamies.forEach(triamie => {
				var rand = Math.floor(Math.random()*moveableTile.length);
				var x = moveableTile[rand].x;
				var y = moveableTile[rand].y;
				triamie.setPos(x, y);
				triamie.setTarget(x, y);
			});
		// }

		maxiator = new Maxiator(moveableTile[moveableTile.length - 1].x, moveableTile[moveableTile.length - 1].y);
		maxiator.generator();

		// rand_2 = Math.floor(Math.random() * moveableTile.length);
		time = 0;
        timeDelay();
		requestAnimationFrame(drawGame);
    }
}
function toIndex(x, y){
	return((y * mapW) + x);
}

function getDistance(x1, y1, x2, y2){
	return (Math.abs(Math.sqrt(((x1-x2) * (x1-x2)) + ((y1-y2) * (y1-y2)))));
}
function drawMap() {
	var x = 0, y = 0;
	for(y = camera.startTile[1]; y <= camera.endTile[1]; ++y)
	{
		for(x = camera.startTile[0]; x <= camera.endTile[0]; ++x)
		{
			ctx.shadowColor = "transparent";
			switch(levels[currentLevel].map[((y*mapW)+x)])
			{
				case 0:
					ctx.shadowBlur = 20;
					ctx.shadowColor = "#000";
					ctx.fillStyle = "#000";
					break;
				case 1:
					ctx.fillStyle = "#001010";
				break;
			}
			var x_coordinate = camera.offset[0] + (x*tileW);
			var y_coordinate = camera.offset[1] + (y*tileH);
			eW = tileW/2;
			eH = tileH/2;
			ctx.fillRect( x_coordinate, y_coordinate, tileW, tileH);
			for (let i = bullets.length-1; i > -1 ; i--) {
				bx = bullets[i].x;
				by = bullets[i].y;
				if(circlerect(bullets[i],x_coordinate,y_coordinate,tileW,tileH) && levels[currentLevel].map[((y*mapW)+x)] == 0 && bullets[i].type == "enemy"){
					for (let i = 0; i < 20; i++) {
						var part = new Particals(bx, by, "rgb(255,"+ Math.floor(Math.random()*233)+ ",10)", true, "rect");
						particals.push(part);
						particals[i].update();
						collided = false;
					}
					bullets.splice(i,1);
				}
			}
			for (let i = triBullets.length-1; i > -1 ; i--) {
				bx = triBullets[i].x;
				by = triBullets[i].y;
				if(circlerect(triBullets[i],x_coordinate,y_coordinate,tileW,tileH) && levels[currentLevel].map[((y*mapW)+x)] == 0 && triBullets[i].type == "triamy"){
					for (let i = 0; i < 20; i++) {
						var part = new Particals(bx, by, "rgb(255,"+ Math.floor(Math.random()*233)+ ",10)", true, "rect");
						particals.push(part);
						particals[i].update();
						collided = false;
					}
					triBullets.splice(i,1);
				}
			}
		}
	}
}


function circlerect(circ, x,y,w,h) {
	var distX = Math.abs(circ.x - x - w/2);
	var distY = Math.abs(circ.y - y - h/2);
  
	if (distX > (w/2 + circ.r)) { return false; }
	if (distY > (h/2 + circ.r)) { return false; }
  
	if (distX <= (w/2)) { return true; } 
	if (distY <= (h/2)) { return true; }
  
	var dx=distX-w/2;
	var dy=distY-h/2;
	return (dx*dx+dy*dy<=(circ.r*circ.r));
}
function collisionDetection(x1,y1,w1,h1, x2,y2,w2,h2) {
	var distX = Math.abs(x1 - x2 - w2/2);
	var distY = Math.abs(y1 - y2 - h2/2);
  
	if (distX > (w2/2 + w1)) { return false; }
	if (distY > (h2/2 + h1)) { return false; }
  
	if (distX <= (w2/2)) { return true; } 
	if (distY <= (h2/2)) { return true; }
  
	var dx=distX-w2/2;
	var dy=distY-h2/2;
	return (dx*dx+dy*dy<=(w1*h1));
}

function drawPlayer(healthBar){

	player.dimensions[0] = tileW/3;
	player.dimensions[1] = tileH/1.5;
	pet.dimensions[0] = player.dimensions[0];
	pet.dimensions[1] = player.dimensions[1]/2;
	var eyeDim = player.dimensions[0]/6;
	pet.moveSpeed = player.delayMove;

	//Pet
	// ctx.shadowBlur = 10;
	// ctx.shadowColor = "rgb(255,150,0)";
	drawImages(0, 51, 50, 50, camera.offset[0] + pet.position[0] - tileW/1.5, camera.offset[1] + pet.position[1] + player.dimensions[1]/2.2,pet.dimensions[0],pet.dimensions[1]);
	ctx.shadowColor = "transparent";

	if (player.health < 25 && gameOver === false) {
		player.color = "rgb(255, 100, 100)";
	}else{
		player.color = "rgb(50, 255, 144)";
	}

	//Health bar
	if(healthBar){
		if(player.health < 25 && pet.health > 10){
			player.health += 1;
			pet.health -= 1;
			var part  = new Particals(camera.offset[0] + pet.position[0] - tileW/1.5, camera.offset[1] + pet.position[1] + pet.dimensions[1]/2, "#fff", false, "arc");
			particals_2.push(part);
		}
		particals_2.forEach(part => {
			part.update();
		});

		var plHel = player.dimensions[0] * player.health * 1.5/100;
		var petHel = pet.dimensions[0] * pet.health/100;
		ctx.fillStyle = player.color;
		ctx.lineWidth = 1;
		ctx.strokeStyle = player.color;
		ctx.strokeRect( camera.offset[0] + player.position[0] + player.dimensions[0] / 8, camera.offset[1] + player.position[1] - player.dimensions[0]/2, player.dimensions[0]*1.5,5);
		ctx.fillRect( camera.offset[0] + player.position[0] + player.dimensions[0] / 8, camera.offset[1] + player.position[1] - player.dimensions[0]/2, plHel,5);
		ctx.fillStyle = "rgb(255,150,0)";
		ctx.strokeStyle = "rgb(255,150,0)";
		ctx.strokeRect(camera.offset[0] + pet.position[0] - tileW/1.5, camera.offset[1] + pet.position[1] + player.dimensions[1]/8, pet.dimensions[0],5);
		ctx.fillRect( camera.offset[0] + pet.position[0] - tileW/1.5, camera.offset[1] + pet.position[1] + player.dimensions[1]/8, petHel,5);
	}

	ctx.shadowBlur = 10;
	ctx.shadowColor = player.color;

	//Body
	ctx.fillStyle = player.color;
	ctx.strokeStyle = player.color;
	ctx.fillRect( camera.offset[0] + player.position[0] + player.dimensions[0]/3 + px, camera.offset[1] + player.position[1] + py,player.dimensions[0] + pw,player.dimensions[1] + ph);
	ctx.shadowColor = "transparent";
	ctx.fillStyle = "#333";

	//Eyes
	ctx.fillRect( camera.offset[0] + player.position[0] + (player.dimensions[0]/2) , camera.offset[1] +player.position[1] + (tileW/4) , eyeDim , eyeDim);
	ctx.fillRect( camera.offset[0] + player.position[0] + (player.dimensions[0])  , camera.offset[1] +player.position[1] + (tileW/4),eyeDim , eyeDim);
	ctx.fillStyle = "rgb(255, 0, 0)";

	//Mouth
	ctx.fillRect( camera.offset[0] + player.position[0] + player.dimensions[0]/2, camera.offset[1] +player.position[1] + (tileW/2),player.dimensions[0]/1.5,5)
	ctx.shadowColor = "transparent";	
}

setInterval(() => {
	mouth++;
}, 150);
setInterval(() => {
	eye++;
}, 300);

function drawEnemy(){
	// var i=0;
	enemys.forEach(enemy => {

		enemy.dimensions = [eW, eH];
		ctx.lineWidth = 1;
		ctx.lineJoin = "round";
		ctx.fillStyle = "#f00";
		ctx.strokeStyle = "#f00";
		var enHel = enemy.dimensions[0]*enemy.health/100;

		//Health bar
		ctx.fillRect(camera.offset[0] + enemy.position[0], camera.offset[1] + enemy.position[1] - 20, enHel,enemy.dimensions[0]/10);
		ctx.strokeRect(camera.offset[0] + enemy.position[0], camera.offset[1] + enemy.position[1] - 20, enemy.dimensions[0],enemy.dimensions[0]/10);
		ctx.fillStyle = enemy.color;

		//Body
		ctx.shadowBlur = 10;
		ctx.shadowColor = enemy.color;
		ctx.fillRect(camera.offset[0] + enemy.position[0], camera.offset[1] + enemy.position[1], enemy.dimensions[0], eH);
		ctx.shadowColor = "transparent";
		ctx.fillStyle = "#333";

		//Eyes
		ctx.shadowBlur = 5;
		ctx.beginPath();
		ctx.shadowColor = "#000";
		ctx.arc( camera.offset[0] + enemy.position[0] + enemy.dimensions[0]/3, camera.offset[1] + enemy.position[1] + enemy.dimensions[1]/3, eye, 0, Math.PI*2,false)
		ctx.arc( camera.offset[0] + enemy.position[0] + enemy.dimensions[0]/1.5, camera.offset[1] + enemy.position[1] + enemy.dimensions[1]/3, eye, 0, Math.PI*2,false)
		ctx.shadowColor = "transparent";
		ctx.fill();
	
		//Mouth
		ctx.shadowColor = "#f44";
		ctx.fillStyle = "#ff3333";
		ctx.fillRect( camera.offset[0] + enemy.position[0] + enemy.dimensions[0]/4, camera.offset[1] +enemy.position[1] + enemy.dimensions[1]/1.5, enemy.dimensions[0]/2,mouth)
		mouth = mouth * mouth%14;
		eye = eye * eye % 4;
		ctx.shadowColor = "transparent";
	});
}

function drawTriamies(){
	var sideCount = 3;
	var size = tileW/3;
	triamies.forEach(triamie => {		
		triamie.dimensions = [tileW/4, tileH/4];
		triamie.moveSpeed = 1200;
		var radians=rotationDegrees*Math.PI/180;
		
		ctx.shadowBlur = 10;
		ctx.fillStyle = triamie.color;
		ctx.strokeStyle = triamie.color;
		var triHel = triamie.dimensions[0]*triamie.health * 2/100;
	
		var x = camera.offset[0] + triamie.position[0] + tileW / 4;
		var y = camera.offset[1] + triamie.position[1] + tileH / 3;
	
		//Health bar
		ctx.fillRect(x - tileH/4, y - tileH/2, triHel,triamie.dimensions[0]/5);
		ctx.strokeRect(x - tileH/4, y - tileH/2, triamie.dimensions[0] * 2,triamie.dimensions[0]/5);
	
		ctx.save();
		ctx.translate(x,y);
		ctx.rotate(radians);
		ctx.beginPath();
		ctx.moveTo (size * Math.cos(0), size * Math.sin(0));
		for (var i = 1; i <= sideCount;i += 1) {
			ctx.lineTo (size * Math.cos(i * 2 * Math.PI / sideCount), size * Math.sin(i * 2 * Math.PI / sideCount));
		}

		// Triamy bullets
		if(bulletCount % 8 === 0){
			triBullets.push(new Bullet( x, y + triamie.dimensions[1]/2 + tileW/20, tileW/20, "rgb(144, 50, 255)", Math.random()*7, 100, 2, "triamy", 5));
		}
		bulletCount += 1;

		ctx.closePath();
		ctx.shadowColor = triamie.color;
		ctx.stroke();
		ctx.fill();
	
		ctx.fillStyle = "#000";
		ctx.shadowColor = "#000";
		ctx.beginPath();
		for (var i = 1; i <= sideCount;i++) {
			ctx.lineTo (size/3 * Math.cos(i * 2 * Math.PI / sideCount), size/3 * Math.sin(i * 2 * Math.PI / sideCount));
		}
		ctx.fill();
		ctx.restore();
		ctx.shadowColor = "transparent";
	});
}

function drawMiniator(){
	miniators.forEach(miniator => {
		var w = miniator.dimensions[0];
		var h = miniator.dimensions[1];
		var x = camera.offset[0] + miniator.position[0];
		var y = camera.offset[1] + miniator.position[1] + h/4;
		// ctx.fillRect(x + w/4,y + h/4,w/2,h/2);
		ctx.save();
		ctx.translate(x + w/2,y + h/2);
		ctx.rotate(0);
		var d = 2;
		ctx.fillStyle = miniator.color;
		ctx.shadowColor = miniator.color;
		ctx.beginPath();
		var sideCounts = miniator.sideCount;
		var size  = w/(d);
		ctx.moveTo (size * Math.cos(0), size * Math.sin(0));
		for (var i = 1; i <= sideCounts;i += 1) {
			ctx.lineTo (size * Math.cos(i * 2 * Math.PI / sideCounts), size * Math.sin(i * 2 * Math.PI / sideCounts));
		}
		ctx.fill();
		ctx.closePath();

		ctx.fillStyle = "#000";
		ctx.shadowBlur = 10;
		ctx.shadowColor = "#000";
		ctx.beginPath();
		var sideCounts = miniator.sideCount;
		var size  = w/(d*2);
		ctx.moveTo (size * Math.cos(0), size * Math.sin(0));
		for (var i = 1; i <= sideCounts;i += 1) {
			ctx.lineTo (size * Math.cos(i * 2 * Math.PI / sideCounts), size * Math.sin(i * 2 * Math.PI / sideCounts));
		}
		ctx.fill();
		ctx.closePath();
		ctx.restore();
		ctx.shadowColor = "transparent";
	});

	for (let i = miniators.length-1; i > -1; i--) {
		const ele = miniators[i];
		if(collisionDetection( camera.offset[0] + ele.position[0],  camera.offset[1] + ele.position[1], ele.dimensions[0], ele.dimensions[1], camera.offset[0] + player.position[0], camera.offset[1] + player.position[1], player.dimensions[0], player.dimensions[0])){
			miniators.splice(i, 1);
			player.health -= 5;
			for (let i = 0; i < tileW/4; i++) {
				var part  = new Particals(camera.offset[0] + ele.position[0],  camera.offset[1] + ele.position[1], ele.color, true, "arc");
				particals_4.push(part);
			}
		}
	}

	particals_4.forEach(part => {
		part.update();
	});

	ctx.save();
	ctx.translate(camera.offset[0] + maxiator.position[0] + maxiator.dimensions[0]/2, camera.offset[1] + maxiator.position[1] + maxiator.dimensions[1]/2);
	var d = 2;
	var sideCounts = getRandomInt(3,10);

	ctx.fillStyle = miniator.color;
	ctx.beginPath();
	var sideCounts = miniator.sideCount;
	var size  = maxiator.dimensions[0]/d;
	ctx.moveTo (size * Math.cos(0), size * Math.sin(0));
	for (var i = 1; i <= sideCounts;i += 1) {
		ctx.lineTo (size * Math.cos(i * 2 * Math.PI / sideCounts), size * Math.sin(i * 2 * Math.PI / sideCounts));
	}
	ctx.fill();
	ctx.closePath();
	ctx.shadowColor = "transparent";

	ctx.fillStyle = "#000";
	ctx.shadowBlur = 10;
	ctx.shadowColor = "#000";
	ctx.beginPath();
	var sideCounts = miniator.sideCount;
	var size  = maxiator.dimensions[0]/(d*2);
	ctx.moveTo (size * Math.cos(0), size * Math.sin(0));
	for (var i = 1; i <= sideCounts;i += 1) {
		ctx.lineTo (size * Math.cos(i * 2 * Math.PI / sideCounts), size * Math.sin(i * 2 * Math.PI / sideCounts));
	}
	ctx.fill();
	ctx.closePath();
	ctx.restore();
	ctx.shadowColor = "transparent";
}
function drawWeapon() {
	ctx.save();
	ctx.translate(weapon.x, weapon.y);
	ctx.rotate(weapon.angle + Math.PI);
	ctx.fillStyle = "rgb(204, 11, 11)";
	drawImages(250,0,50,50, -weapon.w*4, -weapon.h,weapon.w/2,weapon.w/2);
	ctx.fillRect(-weapon.w*1.5, -weapon.h/1.3, weapon.w*1.5,weapon.h);
	ctx.restore();
}

function drawBullet(){
	bullets.forEach(bullet => {
		bullet.draw();
	});
	for(i = bullets.length - 1; i > -1; i--) {
		bullets[i].update();
		bullets[i].checkEnemyCollision(i);
	}
}
// console.log(triamies);

function triamyBullets(){
	triBullets.forEach(triBullet => {
		triBullet.draw();
	});
	for(i = triBullets.length - 1; i > -1; i--) {
		triBullets[i].update();
		triBullets[i].checkTriamyBulletCollision(i);
	}
}

function drawCoin() {
	coins.forEach(coin => {
		coin.draw();
		coin.checkCollision();
	});	
}

function drawHealth() {
	healths.forEach(health => {
		health.draw();
		health.checkCollision();
	});	
}

function gameControls() {
	
	// Gravity
	// if(!inMotion && player.tileFrom[1]<(mapH-1) && levels[currentLevel].map[toIndex(player.tileFrom[0], player.tileFrom[1]+1)] == 1){
	// 	player.tileTo[1] += 1;
	// }

	if(keysDown[32] && fire <= bulletLimit){
		bullets.push(new Bullet(weapon.x, weapon.y + weapon.h/5, weapon.h/5 , "rgb(255," + Math.floor(Math.random() * 255) + ",0)",weapon.angle + Math.PI, 500, 10 , "enemy", 10));
		fire++;
	}

	// Up
	if(keysDown[38] && player.tileFrom[1]>0 && levels[currentLevel].map[toIndex(player.tileFrom[0], player.tileFrom[1]-1)]==1) {
		player.tileTo[1] -= 1;
	}

	// Down
	if(keysDown[40] && player.tileFrom[1]<(mapH-1) && levels[currentLevel].map[toIndex(player.tileFrom[0], player.tileFrom[1]+1)]==1) { 
		player.tileTo[1] += 1;
	}

	// Left
	if(keysDown[37] && player.tileFrom[0]>0 && levels[currentLevel].map[toIndex(player.tileFrom[0]-1, player.tileFrom[1])]==1) { 
		player.tileTo[0] -= 1;
	}
	
	// Right
	if(keysDown[39] && player.tileFrom[0]<(mapW-1) && levels[currentLevel].map[toIndex(player.tileFrom[0]+1, player.tileFrom[1])]==1) { 
		player.tileTo[0] += 1; 
	}
}
function screenShake(collided){
	if(collided){
		var ch = Math.floor(Math.random()*4);
		shakeVel = [0,0];
		switch (ch) {
			case 1:
				shakeVel = [-tileW*5,-tileW*5];
				break;
			case 2:
				shakeVel = [tileW*5,tileW*5];
				break;
			case 3:
				shakeVel = [tileW*5,-tileW*5];
				break;
			case 4:
				shakeVel = [-tileW*5,tileW*5];
				break;
			default:
				shakeVel = [-tileW*5,tileW*5];
		}
		camera.screen[0] += Math.cos(shakeVel[0]);
		camera.screen[1] += Math.sin(shakeVel[1]);
	}
}

function scoreBoard(){
	ctx.font = "bold 10px sans-serif";
	ctx.fillStyle = "#ff0000";
	ctx.fillText("FPS: " + framesLastSecond, c.width - 100, 20);
	ctx.fillStyle = "rgb(233, 233, 233)";
	ctx.fillText( "Score: "+ playerScore, 10,25);
	ctx.fillText( "Kills: "+ playerScore/10, 90,25);

	ctx.font = "20px Arial black";
	ctx.fillText( "Level: "+ levels[currentLevel].level, c.width/2- 50,30);
	
	ctx.font = "bold 10px sans-serif";
	ctx.shadowBlur = 5;
	ctx.shadowColor = "rgb(100, 255, 144)";
	ctx.fillStyle = "rgb(100, 255, 144)";
	ctx.strokeStyle = "rgb(50, 255, 144)";
	
	if(player.health < 25){
		ctx.fillStyle = "rgb(255, 0, 0)";
		ctx.strokeStyle = "rgb(255, 0, 0)";
		ctx.shadowColor = "rgb(255, 0, 0)";
	}	

	ctx.fillRect(50,110,player.health,10);
	ctx.lineWidth = 2;
	ctx.strokeRect(50,110,100,10);
	ctx.shadowColor = "transparent";
	ctx.fillStyle = "rgb(100, 255, 144)";
	ctx.fillText("Health: ", 10,120);
	ctx.fillText(player.health,160,120);
	
	ctx.fillStyle = "rgb(255,150,0)";
	ctx.shadowColor = "rgb(255,150,0)";
	ctx.fillRect(50,85,pet.health,10);
	ctx.fillText(Math.ceil(pet.health),160,95)
	ctx.lineWidth = 2;
	ctx.strokeStyle = "rgb(255,150,0)";
	ctx.strokeRect(50,85,100,10);
	ctx.shadowColor = "transparent";
	ctx.fillText("Pet: ", 10,95);

	ctx.fillStyle = "rgb(255, 0, 0)";
	ctx.fillText("Enemies alive: "+ (triamies.length + enemys.length) + " / " + numOfEnemys, 10,50);
	
	ctx.fillStyle = "rgb(243, 233, 0)";
	ctx.fillText("Coins collected: "+ coinsCollected, 10,70);

}

function loading() {
	if (!drawNow) {
		loadTime = (mapW*10);
		
		ctx.fillStyle = "#001010";
		ctx.fillRect(0,0,c.width,c.height);
		
		for (let i = 0; i < tileW; i++) {
			var part = new Particals(Math.random() * c.width, Math.random() * c.height, "#fff", true, "arc");
			particals.push(part);
			particals[i].update();
		}

		ctx.font = "10px sans-serif";
		diff = ((time / loadTime) * Math.PI*2*10).toFixed(2);
		ctx.fillStyle = "#fff";
		ctx.fillText(Math.floor(time / (loadTime/100)) +'%', c.width/2 - tileW/10, c.height/2 + tileW/15);
		ctx.strokeStyle = "rgb(100,144,255)";
		ctx.shadowColor = "rgb(100,144,255)";
		ctx.strokeStyle = colors[rand_col];
		ctx.shadowColor = colors[rand_col];
		ctx.beginPath();
		ctx.lineWidth = 1;
		ctx.arc( c.width/2, c.height/2, tileW/2, 0, Math.PI * 2, false);
		ctx.stroke();

		ctx.beginPath();
		ctx.lineWidth = tileW/10;
		ctx.fillStyle = "rgb(100,150,144)";
		ctx.arc( c.width/2, c.height/2, tileW/2, start, diff / 10 + start, false);
		ctx.stroke();
		
	}
}
var oldTimeStamp = 0;

function drawGame()
{

	var sec = Math.floor(Date.now()/1000);
	if(sec!=currentSecond)
	{
		currentSecond = sec;
		framesLastSecond = frameCount;
		frameCount = 1;
	}
	else { frameCount++; }	

	camera.update(player.position[0] + c.width/4, player.position[1]+ c.height/4);
	nextTime=time+delay;
	rotationDegrees+=rotationIncrement;

	pointer.x = mouse.x;
	pointer.y = mouse.y;

	//pet Collision with enemies
	for (let i = enemys.length-1; i > 0; i--) {
		if (collisionDetection(enemys[i].position[0], enemys[i].position[1],enemys[i].dimensions[0], enemys[i].dimensions[1], pet.position[0] - tileW, pet.position[1], pet.dimensions[0], pet.dimensions[1]) && startCollision) {
			var part  = new Particals(camera.offset[0] + pet.position[0] - tileW/1.5, camera.offset[1] + pet.position[1] + pet.dimensions[1]/2,"#aaa", true);
			particals.push(part);
			enemys[i].health -= 0.5;
			if(enemys[i].health <=0 ){
				enemys.splice(i,1);
			}
			pet.health -= 0.2;
			if(pet.health <= 0){
				pet.setPos(Math.floor(Math.random()*mapW/2+1),0);
				pet.health = 50;
			}
		}
	}

	weapon.angle = Math.atan2(pointer.y - weapon.y, pointer.x - weapon.x);
	weapon.x = camera.offset[0] + player.position[0] + player.dimensions[0];
	weapon.y = camera.offset[1] + player.position[1] + player.dimensions[1]/1.5;
	weapon.w = player.dimensions[0];
	weapon.h = player.dimensions[1]/4;

	// console.log(triamies.angle);
	
	if(keysDown[37]){
		if(px < 15 && pw < 15){
			pw += 1;
		}
	}
	if(keysDown[39]){
		if(pw < 15 && px > -15){
			pw += 1;
			px -= 1;
		}
	}
	if(keysDown[40]){
		if(ph < 10){
			ph += 1;
			py -= 1;
		}
	}
	// if(keysDown[38]){
	// 	if(ph < 15){
	// 		py -= 1;
	// 		ph += 1;
	// 	}
	// }
	
	var currentFrameTime = Date.now();
	var sec = Math.floor(Date.now()/1000);
	if(sec!=currentSecond)
	{
		currentSecond = sec;
	}
	if(lastFrameTime==0)
	{
		lastFrameTime = Date.now();
		requestAnimationFrame(drawGame);
		return;
	}	
	var timeElapsed = Date.now()-lastFrameTime;
	gameTime += (timeElapsed * gameSpeed);
	
	enemys.forEach(enemy => {		
		enemy.update(gameTime);
	});
	triamies.forEach(triamie => {		
		triamie.update(gameTime);
	});
	miniators.forEach(min => {
		min.update(gameTime);
	});
	pet.update(gameTime);

	if(!player.processMovement(currentFrameTime))
	{
		gameControls();
		if(player.tileFrom[0]!=player.tileTo[0] || player.tileFrom[1]!=player.tileTo[1])
		{ player.timeMoved = currentFrameTime; }	
	}

	//draw playground
	
	if(!gameOver){

		ctx.fillStyle = "#001010";
		ctx.fillRect(0, 0, camera.screen[0], camera.screen[1]);
		for (let i = 0; i < tileW/2; i++) {
			var part = new Particals(Math.random() * c.width, Math.random() * c.height, "#fff", true, "arc");
			particals_3.push(part);
			particals_3[i].update();
		}

		drawMap();	
		loading();
		if(drawNow){
			$(".inventory").css("display","flex");
			drawCoin();
			drawHealth();
			drawBullet();
            drawWeapon();
			drawEnemy();
			drawTriamies();
			triamyBullets();
			drawMiniator();
			drawPlayer(true);
			startCollision = true;
			scoreBoard();
			controllers();
			if(enemys.length == 0 && triamies.length == 0){
				exit.x = moveableTile[moveableTile.length - 1].x * tileW + tileW/4;
				exit.y = moveableTile[moveableTile.length - 1].y * tileH + tileH/4;
				exit.w = tileW/1.3;
				exit.h = tileH/1.3;
				ctx.lineWidth = 5;
				ctx.shadowBlur = 15;
				ctx.shadowColor = "rgb(50, 144, 255)";
				ctx.strokeStyle = "rgb(50, 144, 255)";
				ctx.shadowColor = colors[rand_col];
				ctx.strokeStyle = colors[rand_col];
				ctx.strokeRect(camera.offset[0] + exit.x - exit.w/8 , camera.offset[1] + exit.y, exit.w, exit.h);
				ctx.fillStyle = "rgb(255," + Math.floor(Math.random() * 200) + ",0)";
				ctx.font =  tileW/6 +"px arial black";
				ctx.shadowColor = "transparent";
				ctx.fillText("Exit", camera.offset[0] + exit.x + exit.w/6, camera.offset[1] + exit.y - exit.h/7);
			}
			$(".health p").text(healthCollected);
        }else{
			startCollision = false;
		}

		if(getDistance(player.position[0], player.position[1], exit.x, exit.y) < exit.w/2 && enemys.length == 0){
			pet.setTarget(0, 0);
			gameOv();
		}
	}else{
		ctx.fillStyle = "#001010";
		ctx.fillRect(0,0,c.width,c.height);
		ctx.font = tileW/2 + "px arial black";
		for (let i = 0; i < tileW; i++) {
			var part = new Particals(Math.random() * c.width, Math.random() * c.height, "rgb(255,"+ Math.floor(Math.random()*233)+ ",10)", true, "rect");
			particals.push(part);
			particals[i].update();
		}
		ctx.fillText(gameStatus,c.width/2.5,c.height/2 - tileW);
		player.color = "rgb(50,255,144)";
		drawPlayer(false);
		$(".restart").css("display","block");
		$(".inventory").css("display","none");
	}

	lastFrameTime = currentFrameTime;
	requestAnimationFrame(drawGame);
}

setInterval(() => {
	particals = [];
	particals_3 = [];
	camera.screen = [c.width, c.height];
}, 100);

function timeDelay() {
	setInterval(() => {
		if(time < loadTime){
			time++;
		}else{
			enemys.forEach(enemy => {
				enemy.moveSpeed = 1200;
			});
			drawNow = true;		
		}
	}, 30);
}

function gameOv() {
	setTimeout(() => {
		gameStatus = "Level up: " + (currentLevel+1); 	
		gameOver = true;
		$(".nxt").css("display", "block");
		$(".restart").css("display","none");
	}, 1000);
}
timeDelay();
setInterval(() => {
	particals_4 = [];
}, 400);