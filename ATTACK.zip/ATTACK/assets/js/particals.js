function Particals(x,y, color, vel, shape) {
    this.rand = Math.floor(Math.random()*7);
    this.dimensions = [this.rand,this.rand];
    this.position = [x,y];
    this.realPosition = [x,y];
    this.velocity = [0,0];
	this.color = color;
    this.addVelo = vel;
    this.shape = shape;
    this.addParticaleVelocity = ()=>{
        var ch = Math.floor(Math.random()*4);
        switch (ch) {
            case 1:
                this.velocity = [-Math.random()*5,-Math.random()*5];
                break;
            case 2:
                this.velocity = [Math.random()*5,Math.random()*5];
                break;
            case 3:
                this.velocity = [Math.random()*5,-Math.random()*5];
                break;
            case 4:
                this.velocity = [-Math.random()*5,Math.random()*5];
                break;
            default:
                this.velocity = [-Math.random()*5,Math.random()*5];
        }

    }
    this.draw = function(){
        ctx.fillStyle = this.color;
        ctx.shadowColor = this.color;
        if(this.shape == "arc"){
            ctx.shadowBlur = 15;
            ctx.beginPath();
            ctx.arc(this.position[0],this.position[1], this.rand/2,0,Math.PI*2,false);
            ctx.fill();
        }else{
            ctx.shadowBlur = 30;
            ctx.fillRect(this.position[0],this.position[1],this.dimensions[0],this.dimensions[1]);
            ctx.shadowColor = "transparent";
        }
    }
    this.update = ()=>{
        this.position[0] += this.velocity[0];
        this.position[1] += this.velocity[1];
        if(this.addVelo){
            this.draw();
            this.addParticaleVelocity();
        }else{
            var vx = 1;
            if(this.realPosition[0] + 50 <= this.position[0]){
                vx = 0;
            }else{
                this.position[0] += vx;
                this.position[1] -= vx/2;    
                this.draw();
            }
        }
    }
}   